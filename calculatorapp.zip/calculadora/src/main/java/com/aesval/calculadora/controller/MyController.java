package com.aesval.calculadora.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;

import com.aesval.calculadora.message.Message;

@RestController
public class MyController {
	
	@GetMapping(path="{oper}/**")
	public Message index(@PathVariable("oper") String oper, HttpServletRequest request){
		String restOfTheUrl = (String) request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
		String[] items = restOfTheUrl.split("/");
		List<String> itemList = new LinkedList<>(Arrays.asList(items)) ;
		itemList.removeIf(it->it.equals("add")||it.equals("subs")||it.equals("mult")||it.equals("div")||it.equals(""));
		List<Double> intList = new ArrayList<>(itemList.size());
		itemList.forEach(s->intList.add(Double.parseDouble(s)));
		Message message = new Message();
		if (itemList.size() > 1) {
			Double result = 0.0;
			if (oper.equals("add")) {
				result =  (double) intList.stream().mapToInt(i->i.intValue()).sum();
				message.setName("add");
				message.setResult(result.toString());
				return message;
			}else if(oper.equals("subs")){
				result = intList.get(0).doubleValue();
				for (int j = 1; j < intList.size(); j++) {
					result -= intList.get(j);
				}
				message.setName("subs");
				message.setResult(result.toString());
				return message;
			}else if(oper.equals("mult")){
				result = intList.get(0);
				for (int j = 0; j < intList.size(); j++) {
					result *= intList.get(j);
				}
				message.setName("mult");
				message.setResult(result.toString());
				return message;
			}else if(oper.equals("div")){
				result = intList.get(0).doubleValue();
				for (int j = 1; j < intList.size(); j++) {
					result /= intList.get(j);
				}
				message.setName("div");
				message.setResult(result.toString());
				return message;
			}else{
				message.setResult("Operador invalido");
				return message;
			}
			
		}else{
			message.setName("Error");
			message.setResult("Se necesita un segundo valor");
		}
		System.out.println(oper+" "+restOfTheUrl);
		return null;
	}

}
